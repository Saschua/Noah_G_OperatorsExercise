import UIKit

var number1 = 20
var number2 = 4

let addition = number1 + number2
let subtract = number1 - number2
let multiplication = number1 * number2
let division = number1 / number2

print ("\(number1) + \(number2) = \(addition)")
print ("\(number1) - \(number2) = \(subtract)")
print ("\(number1) * \(number2) = \(multiplication)")
print ("\(number1) / \(number2) = \(division)")
